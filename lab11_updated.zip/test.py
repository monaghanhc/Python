from geometry import *
import time

def main():
    win = Window(500,500)
    time.sleep(3)
    win.close()
    
    win = Window(500,500)
    p = Point(100,50)
    print(p.__str__())
    #print(p[0], p[1])            #Works with geometryU.py
    win.render(p)
    time.sleep(3)
    win.close()
    
    win = Window(500,500)
    c = Circle(250,250,50)
    print(c.__str__())
    win.render(c)
    time.sleep(3)
    win.close()
    
    win = Window(500,500)
    p1 = Point(100,170)
    p2 = Point(200,250)
    p3 = Point(300,280)
    t = Triangle(p1,p2,p3)
    print(t.__str__())
    win.render(t)
    time.sleep(3)
    win.close()
    
main()
