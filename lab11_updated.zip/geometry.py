# geometry.py
# Authors: Anthony Morrell, John Zelle, Hunter Monaghan
# I certify that this lab is my own work

import tkinter as tk
import math

_root = tk.Tk()
_root.withdraw()


class Window(tk.Canvas):
    _config = {'outline': 'black', 'fill': ''}

    def __init__(self, width, height):
        master = tk.Toplevel(_root)
        master.protocol("WM_DELETE_WINDOW", self.close)
        tk.Canvas.__init__(self, master, width=width, height=height,
                           highlightthickness=0, bd=0)
        self.master.title("Geometry Window")
        self.pack()
        self.height = int(height)
        self.width = int(width)
        self.closed = False
        master.lift()
        _root.update()

    def render(self, obj):
        className = type(obj).__name__
        methodName = '_render' + className
        if methodName not in Window.__dict__:
            raise Exception("Unknown shape type '" + className + "'")
        Window.__dict__[methodName](self, obj)
        _root.update()

    def _renderPoint(self, pt):
        x = pt.getX()
        y = pt.getY()
        self.create_rectangle(x, y, x + 1, y + 1, Window._config)

    def _renderCircle(self, cir):
        cp = cir.getCenter()
        cx, cy = cp.getX(), cp.getY()
        rad = cir.getRadius()
        self.create_oval(cx - rad, cy - rad, cx + rad, cy + rad, Window._config)

    def _renderTriangle(self, tri):
        verts = tri.getP1(), tri.getP2(), tri.getP3()
        coords = []
        for vert in verts:
            coords += [vert.getX(), vert.getY()]
        self.create_polygon(*coords, Window._config)

    def close(self):
        if not self.closed:
            self.closed = True
            self.master.destroy()
            _root.update()

    def isClosed(self):
        return self.closed

    def getHeight(self):
        return self.height

    def getWidth(self):
        return self.width

    def __str__(self):
        return "Window({}, {})".format(self.getWidth(), self.getHeight())
    
    
class Point:
    x = 0.0
    y = 0.0
    
    def __init__(self, x, y):
        self.x = x
        self.y = y    
    
    def getX(self):
        return self.x
    
    def getY(self):
        return self.y
    
    def __str__(self):
        return "Point({}, {})".format(self.getX(), self.getY())
    
class Circle:
    
    center = Point
    radius = 0.0
    
    def __init__(self, x, y, radius):
        self.center = Point(x, y)
        
        if radius >= 0:
            self.radius = radius
        else:
            radius = 0
    
    def getCenter(self):
        return self.center
    
    def getRadius(self):
        return self.radius
    
    def getArea(self):
        return pow(self.radius,2)*math.pi
      
    def __str__(self):
        return "Circle(CenterPoint: ({},{}), Radius: {}, Area: {})".format(self.center.getX(), self.center.getY(), self.getRadius(), self.getArea())
    
class Triangle:
    
    p1 = Point
    p2 = Point
    p3 = Point
    
    def __init__(self, p1, p2, p3):
        self.p1 = p1
        self.p2 = p2
        self.p3 = p3
    
    def getP1(self):
        return self.p1
    
    def getP2(self):
        return self.p2
    
    def getP3(self):
        return self.p3
      
    def __str__(self):
        return "Triangle(Point1: ({},{}), Point2: ({},{}), Point3: ({},{}))".format(self.p1.getX(), self.p1.getY(), self.p2.getX(), self.p2.getY(), self.p3.getX(), self.p3.getY())



    
