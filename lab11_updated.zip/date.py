# date.py
# Name: Hunter Monaghan
# I certify that this lab is my own work.

class Date:
    # Represents a date composed of a day, month, and year.
    def __init__(self, day, month, year):    
        self.setDay(day)
        self.setMonth(month)    
        self.year = year

    def getDay(self):
        return self.day
    
    def setDay(self, day):
        if day >= 1 and day <= 31:
            self.day = day
        else:
            self.day = 1

    def getMonth(self):
        return self.month
    
    def setMonth(self, month):
        if month >= 1 and month <= 12:
            self.month = month
        else:
            self.month = 1

    def getYear(self):
        return self.year
    
    def setYear(self, year):
        self.year = year

    # Returns whether or not this date represents a leap day
    def isLeapDay(self):
        return self.month == 2 and self.day == 29

    # Returns whether or not this date occurs before a specified date
    def isBefore(self, other):
        sameMonth = self.month == other.month and self.day < other.day
        sameYear = self.year == other.year and (self.month < other.month or sameMonth)
        return self.year < other.year or sameYear

    def __str__(self):
        return "{0:02}/{1:02}/{2}".format(self.month, self.day, self.year)

def main():
    examDate = Date(22, 6, 2020)
    print("The final exam will take place on " + examDate.__str__())
    
    xDate = Date (22, 4, 1992)
    print("\nxDate is before examDate ? " + str(xDate.isBefore(examDate)))
    
    print("\nModifying examDate...")
    examDate.setYear(2030)
    print("The final exam will now take place on " + examDate.__str__())
    
    print("\nTesting input validation...")
    print("Creating Date object with date: 13/40/2040")
    testDate = Date (40,13,2040)
    print("Date object created with date: " + testDate.__str__())

main()
