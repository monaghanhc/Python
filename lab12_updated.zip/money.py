#money.py
#Hunter Monaghan
#I ceritfy that this is my own work 

class money:
    
    dollars = 0
    cents = 0
    
    def __init__(self, dollars=0, cents=0):
        self.dollars = dollars
        self.setCents(cents)
    
    def setDollars(self, dollars):
        self.dollars = dollars
        
    def getDollars(self):
        return self.dollars
    
    def setCents(self, cents):
        if (cents >= 100):
            self.add(cents/100, cents%100)
        else:
            self.cents = cents
    
    def getCents(self):
        return self.cents
    
    def add(self, dollars, cents):
        self.dollars += int(dollars)
        self.cents += cents
        
    def __lt__(self, other):
        if self.dollars == other.dollars:
            return self.cents < other.cents
        else:
            return self.dollars < other.dollars
        
    def __str__(self):
        return "${}.{}".format(self.getDollars(), self.getCents())
        
def main():
    
    print("Testing creation and printing of a money object m1 with no arguments")
    m1 = money()
    print(m1)
    
    print("\nTesting creation and printing of a money object m2 with 3 dollars 115 cents")
    m2 = money(3, 115)
    print(m2)
    
    print("\nTesting add() method by adding 1 dollars 20 cents to the value of m2 object")
    m2.add(1,20)
    print(m2)
    
    m3 = money(6,10)
    print("\nTesting sortability by checking whether m2 object having 5$ 35cents is less than m3 object having $6 10cents")
    print(m2<m3)

main()
